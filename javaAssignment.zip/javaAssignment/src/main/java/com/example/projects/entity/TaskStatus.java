package com.example.projects.entity;

public enum TaskStatus {
	PENDING, 
	IN_PROGRESS, 
	COMPLETED
}