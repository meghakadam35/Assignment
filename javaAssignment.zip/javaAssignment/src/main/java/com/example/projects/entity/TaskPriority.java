package com.example.projects.entity;

public enum TaskPriority {

	LOW, 
    MEDIUM, 
    HIGH
    
}